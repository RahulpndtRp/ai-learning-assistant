# constants.py

WEBSITE_URL = "https://www.akmmusai.pro/"
OPENAI_EMBEDDING_MODEL = "text-embedding-3-small"
OPENAI_LLM_MODEL = "gpt-4o-mini"
